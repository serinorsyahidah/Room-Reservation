/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package admin;

import java.sql.*;
/**
 *
 * @author USER
 */
public class AdminDatabase {
    Connection con ;

    public AdminDatabase(Connection con) {
        this.con = con;
    }
    
    //for register user 
    public boolean saveAdmin(Admin admin){
        boolean set = false;
        try{
            //Insert register data to database
            String query = "insert into admin(name,email,password) values(?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, admin.getName());
           pt.setString(2, admin.getEmail());
           pt.setString(3, admin.getPassword());

           
           pt.executeUpdate();
           set = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return set;
    }
    public Admin logAdmin(String email, String pass){
        Admin user = null;
        try{
        
            String query;
            query = "select * from admin where email=? and password=?";
            PreparedStatement pst =this.con.prepareStatement(query);
            pst.setString(1,email);
            pst.setString(2,pass);

            
            ResultSet rs = pst.executeQuery();
            if(rs.next()){
                user = new Admin();
                user.setId(rs.getInt("id"));
                user.setName(rs.getString("name"));
                user.setEmail(rs.getString("email"));
                user.setPassword(rs.getString("password"));

            }
                
        }catch(Exception e){
            e.printStackTrace();
        }
        return user;
    }
}
