/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crudroom;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USER
 */
public class RoomsDao {

Connection con;
    
    public RoomsDao(Connection con) {
        this.con = con;
    }

    
    //add rooms information to database
    public boolean addRoom(room room){
        boolean test = false;
        
        try {
            String query = "INSERT INTO room (nameofRoom,typeofRoom,detailofRoom,category) values(?,?,?,?)";
            PreparedStatement pst = this.con.prepareStatement(query);
            pst.setString(1, room.getNameofRoom());
            pst.setString(2, room.getTypeofRoom());
            pst.setString(3, room.getDetailofRoom());
            pst.setString(4, room.getCategory());
            pst.executeUpdate();
            test=true;
        }

        catch(Exception e) {
            e.printStackTrace();
        }
        return test;
    }
    
    //retrieve the book details from database
    public List<room> getAllRoom() {
        
        List<room> room = new ArrayList<>();
        
        try {
            String query = "select * from room";
            PreparedStatement pt = this.con.prepareStatement(query);
            ResultSet rs = pt.executeQuery();
            while(rs.next()){
                int id = rs.getInt("id");
                String NameofRoom =rs.getString("nameofRoom");
                String TypeofRoom =rs.getString("typeofRoom");
                String DetailofRoom =rs.getString("detailofRoom");
                String Category =rs.getString("category");
                
                room row = new room(id,NameofRoom,TypeofRoom,DetailofRoom,Category);
                room.add(row);
            }
        }
        catch(Exception e) {
            e.printStackTrace();;
        }
        return room;
    }
    
//    edit room information
    public boolean editRoomInfo(room room){
        boolean test = false;
        
        try{
            String query = "update room set nameofRoom=?, typeofRoom=?, detailofRoom=?, category=? where id=?";
            PreparedStatement pt = this.con.prepareStatement(query);
            pt.setString(1, room.getNameofRoom());
            pt.setString(2, room.getTypeofRoom());
            pt.setString(3, room.getDetailofRoom());
            pt.setString(4, room.getCategory());
            pt.setInt(5, room.getId());
            pt.executeUpdate();
            test = true;
        }catch(Exception ex){
            ex.printStackTrace();;
        }
    return test;
    }
    
    
//    get single room information in edit page
    public room getSingleRoom(int id){
        room bk = null;
        
        try{
            String query = "select * from room where id=? ";
            
            PreparedStatement pt = this.con.prepareStatement(query);
            pt.setInt(1, id);
            ResultSet rs= pt.executeQuery();
            
            while(rs.next()){
                int bid = rs.getInt("id");
                String NameofRoom =rs.getString("nameofRoom");
                String TypeofRoom =rs.getString("typeofRoom");
                String DetailofRoom =rs.getString("detailofRoom");
                String Category =rs.getString("category");
                bk = new room(bid,NameofRoom,TypeofRoom,DetailofRoom,Category);
            }
        }catch(Exception ex){
            ex.printStackTrace();;
        }
        return bk;
    }
    
    
//    delete rooms from database
    
    
    public void deleteRoom(int id){
        try{
            
           String query= "delete from room where id=?";
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setInt(1, id);
           pt.execute();
            
        }catch(Exception ex){
            ex.printStackTrace();;
        }
    }
}
