/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crudroom;

/**
 *
 * @author USER
 */
public class room {
    int id;
    String nameofRoom;
    String typeofRoom;
    String detailofRoom;
    String category;

    public room() {
    }

    public room(int id, String nameofRoom, String typeofRoom, String detailofRoom, String category) {
        this.id = id;
        this.nameofRoom = nameofRoom;
        this.typeofRoom = typeofRoom;
        this.detailofRoom = detailofRoom;
        this.category = category;
    }

    public room(String nameofRoom, String typeofRoom, String detailofRoom, String category) {
        this.nameofRoom = nameofRoom;
        this.typeofRoom = typeofRoom;
        this.detailofRoom = detailofRoom;
        this.category = category;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNameofRoom() {
        return nameofRoom;
    }

    public void setNameofRoom(String nameofRoom) {
        this.nameofRoom = nameofRoom;
    }

    public String getTypeofRoom() {
        return typeofRoom;
    }

    public void setTypeofRoom(String typeofRoom) {
        this.typeofRoom = typeofRoom;
    }

    public String getDetailofRoom() {
        return detailofRoom;
    }

    public void setDetailofRoom(String detailofRoom) {
        this.detailofRoom = detailofRoom;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    @Override
    public String toString() {
        return "room{" + "id=" + id + ", nameofRoom=" + nameofRoom + ", typeofRoom=" + typeofRoom + ", detailofRoom=" + detailofRoom + ", category=" + category + '}';
    }
}
    